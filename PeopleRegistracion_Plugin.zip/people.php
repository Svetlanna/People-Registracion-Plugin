<style type="text/css">
	table, th, td {
   border: 1px solid black;
}
</style>
<?php




$servername =DB_HOST;
$username =DB_USER;
$password =DB_PASSWORD;
$dbname =DB_NAME;
 $pdo = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
$st = $pdo->prepare("SELECT * FROM wp_people");
	$st->execute(array());
	$arr = $st->fetchAll(PDO::FETCH_ASSOC);
  echo '
   <table class="table" bordered="0">  
        <tr>  
        <th>Name</th>  
        <th>description</th>  
        <th>img</th>  
       <th>phone</th>
       <th>email</th>
       <th>adress</th>
    </tr>
  ';
 foreach ($arr as $row) {
 echo '
    <tr>  
         <td>'.$row["name"].'</td>  
         <td>'.$row["description"].'</td>  
         <td>'.$row["image"].'</td>  
         <td>'.$row["phone_num"].'</td>  
         <td>'.$row["email"].'</td>
         <td>'.$row["adress"].'</td>
   		<td>
   		<a href="/wpt/wp-admin/admin.php?page=manage-Peoples&show='.$row["id"].'">Show</a>
   		</td>  
    </tr>
   ';
  }
if(isset($_GET['show'])) {

$id=$_GET['show'];

$st = $pdo->prepare("SELECT * FROM wp_people where id=".$id."");
	$st->execute(array());
	$arr = $st->fetchAll(PDO::FETCH_ASSOC);
	echo "<h3>".$arr[0]['name']."</h3>";
	echo "<p>".$arr[0]['description']."</p><br>";
	echo "<img src='".$arr[0]['image']."'>".$arr[0]['image']."<br>";
	echo "<p>".$arr[0]['phone_num']."</p><br>";
	echo "<p>".$arr[0]['email']."></p><br>";
	echo $arr[0]['adress']."<br>";
} else {
echo 'second page';

}

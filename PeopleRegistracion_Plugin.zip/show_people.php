<?php
$dirname = dirname(__FILE__);
$root = false !== mb_strpos( $dirname, 'wp-content' ) ? mb_substr( $dirname, 0, mb_strpos( $dirname, 'wp-content' ) ) : $dirname;
require_once( $root . "wp-config.php" );


$servername =DB_HOST;
$username =DB_USER;
$password =DB_PASSWORD;
$dbname =DB_NAME;
$id=$_GET['show'];

 $pdo = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
$st = $pdo->prepare("SELECT * FROM wp_people where id=".$id."");
	$st->execute(array());
	$arr = $st->fetchAll(PDO::FETCH_ASSOC);
	echo "<h3>".$arr[0]['name']."</h3>";
	echo "<p>".$arr[0]['description']."</p><br>";
	echo "<img src='".$arr[0]['image']."'>".$arr[0]['image']."<br>";
	echo "<p>".$arr[0]['phone_num']."</p><br>";
	echo "<p>".$arr[0]['email']."></p><br>";
	echo $arr[0]['adress']."<br>";

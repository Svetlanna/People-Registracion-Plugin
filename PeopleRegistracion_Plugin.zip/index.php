<?php
/*
Plugin Name:People
   Version: 1
   Author: Svetlanna Sultanyan

*/

   $dirname = dirname(__FILE__);
$root = false !== mb_strpos( $dirname, 'wp-content' ) ? mb_substr( $dirname, 0, mb_strpos( $dirname, 'wp-content' ) ) : $dirname;
require_once( $root . "wp-config.php" );


$servername =DB_HOST;
$username =DB_USER;
$password =DB_PASSWORD;
$dbname =DB_NAME;
function create_posttype() {
    register_post_type( 'movies',
        array(
            'labels' => array(
                'name' => __( 'Movies' ),
                'singular_name' => __( 'Movie' )
            ),
            'public' => true,
            'has_archive' => true,
            'rewrite' => array('slug' => 'movies'),
        )
    );
}
add_action( 'init', 'create_posttype' );
function plugin_activated()
{
global $wpdb;
$charset_collate = $wpdb->get_charset_collate();
   $table_name = $wpdb->prefix . "people"; 
$sql = "CREATE TABLE $table_name (
  id int(11) NOT NULL AUTO_INCREMENT,
  name varchar(255) DEFAULT '' NOT NULL,
  description text NOT NULL,
  image varchar(255) DEFAULT '' NOT NULL,
  phone_num varchar(55) DEFAULT '' NOT NULL,
  email varchar(255) DEFAULT '' NOT NULL,
  adress varchar(55) DEFAULT '' NOT NULL,
  PRIMARY KEY  (id)
) $charset_collate;";

require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
dbDelta( $sql );
}
register_activation_hook( __FILE__, "plugin_activated");
function form_creation(){
?>
<form action='wpt/wp-content/plugins/people/index.php' method='post'enctype="multipart/form-data">
Name : <input type="text" name="name"><br>
description: <textarea name='description' placeholder='ENTER TEXT...'></textarea>
image: <input type="file" name="image"><br>
Phone number: <input type="text" name="phone_number"><br>
Email: <input type="email" name="email"><br>
Adress: <input type="text" name="adress"><br>
<button>Save</button>
</form>
<?php
}
add_shortcode("test", "form_creation");
  if ($_SERVER['REQUEST_METHOD']=="POST" and isset($_POST["name"])){    
    $name=$_POST["name"];
    $description=$_POST["description"];
    $image=$_POST["image"];
    $phone_number=$_POST["phone_number"];
    $email=$_POST["email"];
    $adress=$_POST["adress"];
try {
      $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    $uploaddir = '/var/www/html/wpt/wp-content/plugins/people/img';
    $uploadfile = $uploaddir . $_FILES['image']['name'];
     move_uploaded_file($_FILES['image']['tmp_name'], $uploadfile); 
    echo "File is valid, and was successfully uploaded.\n";
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $sql = "INSERT INTO wp_people (name, description,image,phone_num, email,adress)
    VALUES ('$name','$description', '$uploadfile','$phone_number', '$email', '$adress')";
    $conn->exec($sql);
    echo "New record created successfully";
   }
catch(PDOException $e)
    {
    echo $sql . "<br>" . $e->getMessage();
    }
}
add_action('admin_menu', 'mt_add_pages');
function mt_add_pages() {
    add_menu_page(__('People','menu-test'), __('People','menu-test'), 'manage_options', 'manage-Peoples', 'People_page' );
    add_submenu_page('People', __('menu-test'), __('menu-test'), 'manage_options', 'add-People', 'add_new_People_page');
}
function People_page() {
    if (!current_user_can('manage_options'))
    {
      wp_die( __('You do not have sufficient permissions to access this page.') );
    }
    echo "<br/>";
    echo "<h2>" . __( 'Manage Peoples', 'menu-test' ) . "</h2>";
    include_once 'people.php';
}
function add_new_People_page() {
    if (!current_user_can('manage_options'))
    {
      wp_die( __('You do not have sufficient permissions to access this page.') );
    }
    echo "<br/>";
    include_once 'people.php';
}